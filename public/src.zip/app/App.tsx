import { PAIShowcase } from "./components/PAIShowcase";

export default function App() {
  return <PAIShowcase />;
}
