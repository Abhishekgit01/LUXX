import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Play, Pause, Download } from "lucide-react";

// Import all animation frames
import PAI_Idle_01 from "./pai/PAI_Idle_01";
import PAI_Idle_02 from "./pai/PAI_Idle_02";
import PAI_Idle_03 from "./pai/PAI_Idle_03";
import PAI_Idle_04 from "./pai/PAI_Idle_04";
import PAI_Blink_01 from "./pai/PAI_Blink_01";
import PAI_Blink_02 from "./pai/PAI_Blink_02";
import PAI_Blink_03 from "./pai/PAI_Blink_03";
import PAI_Blink_04 from "./pai/PAI_Blink_04";
import PAI_Wave_01 from "./pai/PAI_Wave_01";
import PAI_Wave_02 from "./pai/PAI_Wave_02";
import PAI_Wave_03 from "./pai/PAI_Wave_03";
import PAI_Wave_04 from "./pai/PAI_Wave_04";
import PAI_Thinking_01 from "./pai/PAI_Thinking_01";
import PAI_Thinking_02 from "./pai/PAI_Thinking_02";
import PAI_Thinking_03 from "./pai/PAI_Thinking_03";
import PAI_Thinking_04 from "./pai/PAI_Thinking_04";
import PAI_Talking_01 from "./pai/PAI_Talking_01";
import PAI_Talking_02 from "./pai/PAI_Talking_02";
import PAI_Talking_03 from "./pai/PAI_Talking_03";
import PAI_Talking_04 from "./pai/PAI_Talking_04";
import ThoughtBubbles from "./pai/ThoughtBubbles";
import Sparkles from "./pai/Sparkles";

const animations = {
  idle: [PAI_Idle_01, PAI_Idle_02, PAI_Idle_03, PAI_Idle_04],
  blink: [PAI_Blink_01, PAI_Blink_02, PAI_Blink_03, PAI_Blink_04],
  wave: [PAI_Wave_01, PAI_Wave_02, PAI_Wave_03, PAI_Wave_04],
  thinking: [PAI_Thinking_01, PAI_Thinking_02, PAI_Thinking_03, PAI_Thinking_04],
  talking: [PAI_Talking_01, PAI_Talking_02, PAI_Talking_03, PAI_Talking_04],
};

type AnimationType = keyof typeof animations;

export function PAIShowcase() {
  const [currentAnimation, setCurrentAnimation] = useState<AnimationType>("idle");
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showThoughts, setShowThoughts] = useState(false);
  const [showSparkles, setShowSparkles] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentFrame((prev) => (prev + 1) % 4);
    }, 200); // 200ms per frame = 5fps for smooth animation

    return () => clearInterval(interval);
  }, [isPlaying]);

  const CurrentFrame = animations[currentAnimation][currentFrame];

  const handleAnimationChange = (anim: AnimationType) => {
    setCurrentAnimation(anim);
    setCurrentFrame(0);
    setShowThoughts(anim === "thinking");
    setShowSparkles(false);
  };

  const downloadSVG = (Component: () => JSX.Element, name: string) => {
    const svgElement = document.createElement("div");
    svgElement.innerHTML = Component().props.children;
    const svgString = new XMLSerializer().serializeToString(svgElement.firstChild as Element);
    const blob = new Blob([svgString], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${name}.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl mb-4">PAI Mascot Asset Set</h1>
          <p className="text-xl text-slate-600">
            Desktop AI Assistant Mascot · 20 Animation Frames · SVG Vector Assets
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Live Preview */}
          <Card className="p-8 bg-white">
            <div className="mb-6">
              <h2 className="text-2xl mb-2">Live Preview</h2>
              <p className="text-slate-600">Watch PAI animate in real-time</p>
            </div>

            {/* Main Display */}
            <div className="relative bg-gradient-to-br from-slate-100 to-slate-200 rounded-2xl overflow-hidden mb-6 aspect-square flex items-end justify-center">
              <div className="relative w-full h-full">
                {showThoughts && (
                  <div className="absolute inset-0 pointer-events-none">
                    <ThoughtBubbles />
                  </div>
                )}
                {showSparkles && (
                  <div className="absolute inset-0 pointer-events-none">
                    <Sparkles />
                  </div>
                )}
                <div className="w-full h-full">
                  <CurrentFrame />
                </div>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex gap-2">
                <Button
                  onClick={() => setIsPlaying(!isPlaying)}
                  variant="outline"
                  size="sm"
                >
                  {isPlaying ? <Pause className="size-4" /> : <Play className="size-4" />}
                  {isPlaying ? "Pause" : "Play"}
                </Button>
                <Button
                  onClick={() => setCurrentFrame((prev) => (prev + 1) % 4)}
                  variant="outline"
                  size="sm"
                  disabled={isPlaying}
                >
                  Next Frame
                </Button>
              </div>
              <div className="text-sm text-slate-600">
                Frame {currentFrame + 1} / 4
              </div>
            </div>

            {/* Optional Elements */}
            {currentAnimation === "thinking" && (
              <div className="flex gap-2 mb-4">
                <Button
                  onClick={() => setShowThoughts(!showThoughts)}
                  variant={showThoughts ? "default" : "outline"}
                  size="sm"
                >
                  Thought Bubbles
                </Button>
                <Button
                  onClick={() => setShowSparkles(!showSparkles)}
                  variant={showSparkles ? "default" : "outline"}
                  size="sm"
                >
                  Sparkles
                </Button>
              </div>
            )}

            {/* Animation Selector */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => handleAnimationChange("idle")}
                variant={currentAnimation === "idle" ? "default" : "outline"}
              >
                Idle / Curious
              </Button>
              <Button
                onClick={() => handleAnimationChange("blink")}
                variant={currentAnimation === "blink" ? "default" : "outline"}
              >
                Blink
              </Button>
              <Button
                onClick={() => handleAnimationChange("wave")}
                variant={currentAnimation === "wave" ? "default" : "outline"}
              >
                Wave
              </Button>
              <Button
                onClick={() => handleAnimationChange("thinking")}
                variant={currentAnimation === "thinking" ? "default" : "outline"}
              >
                Thinking
              </Button>
              <Button
                onClick={() => handleAnimationChange("talking")}
                variant={currentAnimation === "talking" ? "default" : "outline"}
                className="col-span-2"
              >
                Talking / Excited
              </Button>
            </div>
          </Card>

          {/* Asset Library */}
          <Card className="p-8 bg-white">
            <div className="mb-6">
              <h2 className="text-2xl mb-2">Asset Library</h2>
              <p className="text-slate-600">Browse and download individual frames</p>
            </div>

            <Tabs defaultValue="idle" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="idle">Idle</TabsTrigger>
                <TabsTrigger value="blink">Blink</TabsTrigger>
                <TabsTrigger value="wave">Wave</TabsTrigger>
                <TabsTrigger value="thinking">Think</TabsTrigger>
                <TabsTrigger value="talking">Talk</TabsTrigger>
              </TabsList>

              {Object.entries(animations).map(([key, frames]) => (
                <TabsContent key={key} value={key} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    {frames.map((Frame, index) => (
                      <div
                        key={index}
                        className="relative group bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg overflow-hidden aspect-square"
                      >
                        <Frame />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => downloadSVG(Frame, `PAI_${key}_0${index + 1}`)}
                          >
                            <Download className="size-4 mr-2" />
                            SVG
                          </Button>
                        </div>
                        <div className="absolute bottom-2 left-2 text-xs bg-black/70 text-white px-2 py-1 rounded">
                          {key}_0{index + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              ))}

              <TabsContent value="extras" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative group bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg overflow-hidden aspect-square">
                    <ThoughtBubbles />
                    <div className="absolute bottom-2 left-2 text-xs bg-black/70 text-white px-2 py-1 rounded">
                      Thought Bubbles
                    </div>
                  </div>
                  <div className="relative group bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg overflow-hidden aspect-square">
                    <Sparkles />
                    <div className="absolute bottom-2 left-2 text-xs bg-black/70 text-white px-2 py-1 rounded">
                      Sparkles
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </div>

        {/* Specifications */}
        <Card className="mt-8 p-8 bg-white">
          <h2 className="text-2xl mb-4">Asset Specifications</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="mb-2 text-slate-600">Format</h3>
              <p>SVG Vector (512×512px)</p>
              <p className="text-sm text-slate-500">Scalable to any size</p>
            </div>
            <div>
              <h3 className="mb-2 text-slate-600">Colors</h3>
              <p>Black (#1a1a1a)</p>
              <p>White (#f8f8f8)</p>
              <p>Pink (#ff9fb0)</p>
              <p>Cyan Accent (#4dd4e0)</p>
            </div>
            <div>
              <h3 className="mb-2 text-slate-600">Total Assets</h3>
              <p>20 Animation Frames</p>
              <p className="text-sm text-slate-500">+ 2 optional overlays</p>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t">
            <h3 className="mb-3">Animation Details</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• <strong>Idle:</strong> 4-frame gentle breathing/bobbing animation</li>
              <li>• <strong>Blink:</strong> 4-frame natural eye closing sequence</li>
              <li>• <strong>Wave:</strong> 4-frame friendly paw waving motion</li>
              <li>• <strong>Thinking:</strong> 4-frame head tilt with optional thought elements</li>
              <li>• <strong>Talking:</strong> 4-frame mouth movement for speech</li>
            </ul>
          </div>

          <div className="mt-6 pt-6 border-t">
            <h3 className="mb-3">Usage Notes</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• All frames use transparent backgrounds (no export needed)</li>
              <li>• Consistent positioning across all frames for smooth animation</li>
              <li>• Cat designed to peek from screen edges (bottom/side)</li>
              <li>• Clean silhouette style works on any background</li>
              <li>• Thought bubbles and sparkles are separate toggleable layers</li>
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
}
