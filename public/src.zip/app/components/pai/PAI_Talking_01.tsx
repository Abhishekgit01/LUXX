export default function PAI_Talking_01() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom - more visible */}
      <path
        d="M 256 375 Q 200 365 170 395 Q 150 415 150 445 L 150 512 L 362 512 L 362 445 Q 362 415 342 395 Q 312 365 256 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 395 L 160 355 L 200 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - perked up */}
      <path
        d="M 332 395 L 352 353 L 312 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge - tighter grip */}
      <path
        d="M 165 435 Q 145 435 135 445 Q 125 455 130 470 Q 135 480 150 480 Q 160 480 170 470 L 175 455 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge - tighter grip */}
      <path
        d="M 347 435 Q 367 435 377 445 Q 387 455 382 470 Q 377 480 362 480 Q 352 480 342 470 L 337 455 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - energetic wide */}
      <ellipse cx="210" cy="415" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="215" cy="413" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="217" cy="408" rx="6" ry="8" fill="#ffffff" />
      
      {/* Right eye - energetic wide */}
      <ellipse cx="302" cy="415" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="297" cy="413" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="295" cy="408" rx="6" ry="8" fill="#ffffff" />
      
      {/* Small open mouth - talking */}
      <ellipse cx="256" cy="450" rx="8" ry="6" fill="#1a1a1a" />
      <path d="M 256 450 Q 260 455 256 456 Q 252 455 256 450" fill="#ff9fb0" />
      
      {/* Tiny nose above mouth */}
      <ellipse cx="256" cy="440" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="435" x2="155" y2="430" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="210" y1="443" x2="160" y2="445" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="435" x2="357" y2="430" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="302" y1="443" x2="352" y2="445" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Tail peeking - more curved (excited) */}
      <path
        d="M 362 475 Q 395 463 418 480 Q 428 490 423 502 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
