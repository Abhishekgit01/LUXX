export default function ThoughtBubbles() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Thought dots - can be toggled separately */}
      <circle cx="280" cy="360" r="4" fill="#4dd4e0" opacity="0.8" />
      <circle cx="295" cy="345" r="6" fill="#4dd4e0" opacity="0.7" />
      <circle cx="315" cy="335" r="8" fill="#4dd4e0" opacity="0.6" />
    </svg>
  );
}
