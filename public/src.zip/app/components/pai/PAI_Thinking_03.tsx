export default function PAI_Thinking_03() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat tilted more */}
      <path
        d="M 260 376 Q 204 366 174 396 Q 154 416 154 446 L 154 512 L 366 512 L 366 446 Q 366 416 346 396 Q 316 366 260 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 184 396 L 164 356 L 204 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - tilted more */}
      <path
        d="M 336 393 L 360 353 L 316 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 174 436 Q 154 436 144 446 Q 134 456 139 471 Q 144 481 159 481 Q 169 481 179 471 L 184 456 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw - raised near face thinking */}
      <path
        d="M 291 421 Q 311 416 321 421 Q 331 426 329 439 Q 327 449 314 453 Q 304 455 294 448 L 289 434 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - looking up and to the side */}
      <ellipse cx="214" cy="411" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="215" cy="404" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="217" cy="399" rx="5" ry="7" fill="#ffffff" />
      
      {/* Right eye - looking up and to the side */}
      <ellipse cx="306" cy="411" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="303" cy="404" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="301" cy="399" rx="5" ry="7" fill="#ffffff" />
      
      {/* Tiny nose */}
      <ellipse cx="260" cy="441" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="214" y1="436" x2="164" y2="431" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="214" y1="444" x2="169" y2="446" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Subtle whiskers - right */}
      <line x1="306" y1="436" x2="356" y2="431" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="306" y1="444" x2="351" y2="446" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Tail peeking */}
      <path
        d="M 366 476 Q 394 466 414 481 Q 424 491 419 501 L 374 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
