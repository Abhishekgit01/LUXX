export default function PAI_Idle_02() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom - slight breathing motion (up 3px) */}
      <path
        d="M 256 377 Q 200 367 170 397 Q 150 417 150 447 L 150 512 L 362 512 L 362 447 Q 362 417 342 397 Q 312 367 256 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 397 L 160 357 L 200 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear */}
      <path
        d="M 332 397 L 352 357 L 312 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 170 437 Q 150 437 140 447 Q 130 457 135 472 Q 140 482 155 482 Q 165 482 175 472 L 180 457 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge */}
      <path
        d="M 342 437 Q 362 437 372 447 Q 382 457 377 472 Q 372 482 357 482 Q 347 482 337 472 L 332 457 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - large and expressive */}
      <ellipse cx="210" cy="417" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="215" cy="415" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="217" cy="410" rx="5" ry="7" fill="#ffffff" />
      
      {/* Right eye - large and expressive */}
      <ellipse cx="302" cy="417" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="297" cy="415" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="295" cy="410" rx="5" ry="7" fill="#ffffff" />
      
      {/* Tiny nose */}
      <ellipse cx="256" cy="442" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="437" x2="160" y2="432" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="210" y1="445" x2="165" y2="447" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="437" x2="352" y2="432" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="302" y1="445" x2="347" y2="447" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Tail peeking - curved */}
      <path
        d="M 362 477 Q 390 467 410 482 Q 420 492 415 502 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
