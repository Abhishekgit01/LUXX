export default function PAI_Talking_04() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom */}
      <path
        d="M 256 378 Q 200 368 170 398 Q 150 418 150 448 L 150 512 L 362 512 L 362 448 Q 362 418 342 398 Q 312 368 256 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 398 L 160 358 L 200 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - perked up */}
      <path
        d="M 332 398 L 352 356 L 312 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 168 438 Q 148 438 138 448 Q 128 458 133 473 Q 138 483 153 483 Q 163 483 173 473 L 178 458 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge */}
      <path
        d="M 344 438 Q 364 438 374 448 Q 384 458 379 473 Q 374 483 359 483 Q 349 483 339 473 L 334 458 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - energetic */}
      <ellipse cx="210" cy="418" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="215" cy="416" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="217" cy="411" rx="6" ry="8" fill="#ffffff" />
      
      {/* Right eye - energetic */}
      <ellipse cx="302" cy="418" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="297" cy="416" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="295" cy="411" rx="6" ry="8" fill="#ffffff" />
      
      {/* Mouth - open again talking */}
      <ellipse cx="256" cy="452" rx="9" ry="7" fill="#1a1a1a" />
      <ellipse cx="256" cy="449" rx="4" ry="2" fill="#ff9fb0" />
      
      {/* Tiny nose above mouth */}
      <ellipse cx="256" cy="443" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="438" x2="158" y2="433" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="210" y1="446" x2="163" y2="448" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="438" x2="354" y2="433" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="302" y1="446" x2="349" y2="448" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Tail peeking - curved */}
      <path
        d="M 362 478 Q 392 468 414 483 Q 424 493 419 503 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
