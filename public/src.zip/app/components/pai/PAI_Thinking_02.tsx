export default function PAI_Thinking_02() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat tilted slightly */}
      <path
        d="M 258 378 Q 202 368 172 398 Q 152 418 152 448 L 152 512 L 364 512 L 364 448 Q 364 418 344 398 Q 314 368 258 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 182 398 L 162 358 L 202 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - tilted */}
      <path
        d="M 334 395 L 356 356 L 314 378 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 172 438 Q 152 438 142 448 Q 132 458 137 473 Q 142 483 157 483 Q 167 483 177 473 L 182 458 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw - raised near face thinking */}
      <path
        d="M 288 423 Q 308 418 318 423 Q 328 428 326 441 Q 324 451 311 455 Q 301 457 291 450 L 286 436 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - looking up */}
      <ellipse cx="212" cy="413" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="214" cy="407" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="216" cy="402" rx="5" ry="7" fill="#ffffff" />
      
      {/* Right eye - looking up */}
      <ellipse cx="304" cy="413" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="301" cy="407" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="299" cy="402" rx="5" ry="7" fill="#ffffff" />
      
      {/* Tiny nose */}
      <ellipse cx="258" cy="443" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="212" y1="438" x2="162" y2="433" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="212" y1="446" x2="167" y2="448" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Subtle whiskers - right */}
      <line x1="304" y1="438" x2="354" y2="433" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="304" y1="446" x2="349" y2="448" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Tail peeking */}
      <path
        d="M 364 478 Q 392 468 412 483 Q 422 493 417 503 L 372 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
