export default function PAI_Idle_03() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom - slight breathing motion (up 5px) */}
      <path
        d="M 256 375 Q 200 365 170 395 Q 150 415 150 445 L 150 512 L 362 512 L 362 445 Q 362 415 342 395 Q 312 365 256 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 395 L 160 355 L 200 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - slightly more raised */}
      <path
        d="M 332 395 L 352 353 L 312 375 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 170 435 Q 150 435 140 445 Q 130 455 135 470 Q 140 480 155 480 Q 165 480 175 470 L 180 455 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge */}
      <path
        d="M 342 435 Q 362 435 372 445 Q 382 455 377 470 Q 372 480 357 480 Q 347 480 337 470 L 332 455 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - large and expressive */}
      <ellipse cx="210" cy="415" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="215" cy="413" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="217" cy="408" rx="5" ry="7" fill="#ffffff" />
      
      {/* Right eye - large and expressive */}
      <ellipse cx="302" cy="415" rx="22" ry="28" fill="#f8f8f8" />
      <ellipse cx="297" cy="413" rx="12" ry="16" fill="#1a1a1a" />
      <ellipse cx="295" cy="408" rx="5" ry="7" fill="#ffffff" />
      
      {/* Tiny nose */}
      <ellipse cx="256" cy="440" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="435" x2="160" y2="430" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="210" y1="443" x2="165" y2="445" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="435" x2="352" y2="430" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="302" y1="443" x2="347" y2="445" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Tail peeking - curved */}
      <path
        d="M 362 475 Q 390 465 410 480 Q 420 490 415 500 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
