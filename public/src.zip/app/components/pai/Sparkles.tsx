export default function Sparkles() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Sparkle marks - can be toggled separately */}
      <path d="M 290 350 L 292 360 L 294 350 L 304 352 L 294 354 L 292 364 L 290 354 L 280 352 Z" fill="#4dd4e0" opacity="0.8" />
      <path d="M 320 330 L 323 343 L 326 330 L 339 333 L 326 336 L 323 349 L 320 336 L 307 333 Z" fill="#4dd4e0" opacity="0.7" />
      <path d="M 305 365 L 306 370 L 307 365 L 312 366 L 307 367 L 306 372 L 305 367 L 300 366 Z" fill="#4dd4e0" opacity="0.6" />
    </svg>
  );
}
