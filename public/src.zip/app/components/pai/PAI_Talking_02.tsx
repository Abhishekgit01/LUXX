export default function PAI_Talking_02() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom */}
      <path
        d="M 256 377 Q 200 367 170 397 Q 150 417 150 447 L 150 512 L 362 512 L 362 447 Q 362 417 342 397 Q 312 367 256 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 397 L 160 357 L 200 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - perked up */}
      <path
        d="M 332 397 L 352 355 L 312 377 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 167 437 Q 147 437 137 447 Q 127 457 132 472 Q 137 482 152 482 Q 162 482 172 472 L 177 457 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge */}
      <path
        d="M 345 437 Q 365 437 375 447 Q 385 457 380 472 Q 375 482 360 482 Q 350 482 340 472 L 335 457 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - energetic */}
      <ellipse cx="210" cy="417" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="215" cy="415" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="217" cy="410" rx="6" ry="8" fill="#ffffff" />
      
      {/* Right eye - energetic */}
      <ellipse cx="302" cy="417" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="297" cy="415" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="295" cy="410" rx="6" ry="8" fill="#ffffff" />
      
      {/* Mouth - more open mid-talk */}
      <ellipse cx="256" cy="451" rx="10" ry="8" fill="#1a1a1a" />
      <ellipse cx="256" cy="448" rx="5" ry="3" fill="#ff9fb0" />
      
      {/* Tiny nose above mouth */}
      <ellipse cx="256" cy="442" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="437" x2="157" y2="432" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="210" y1="445" x2="162" y2="447" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="437" x2="355" y2="432" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="302" y1="445" x2="350" y2="447" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Tail peeking - curved */}
      <path
        d="M 362 477 Q 393 467 415 482 Q 425 492 420 502 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
