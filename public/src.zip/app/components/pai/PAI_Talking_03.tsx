export default function PAI_Talking_03() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom */}
      <path
        d="M 256 376 Q 200 366 170 396 Q 150 416 150 446 L 150 512 L 362 512 L 362 446 Q 362 416 342 396 Q 312 366 256 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 396 L 160 356 L 200 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear - perked up */}
      <path
        d="M 332 396 L 352 354 L 312 376 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 166 436 Q 146 436 136 446 Q 126 456 131 471 Q 136 481 151 481 Q 161 481 171 471 L 176 456 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw gripping edge */}
      <path
        d="M 346 436 Q 366 436 376 446 Q 386 456 381 471 Q 376 481 361 481 Q 351 481 341 471 L 336 456 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - energetic */}
      <ellipse cx="210" cy="416" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="215" cy="414" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="217" cy="409" rx="6" ry="8" fill="#ffffff" />
      
      {/* Right eye - energetic */}
      <ellipse cx="302" cy="416" rx="24" ry="30" fill="#f8f8f8" />
      <ellipse cx="297" cy="414" rx="13" ry="17" fill="#1a1a1a" />
      <ellipse cx="295" cy="409" rx="6" ry="8" fill="#ffffff" />
      
      {/* Small mouth - closing */}
      <ellipse cx="256" cy="449" rx="7" ry="5" fill="#1a1a1a" />
      <path d="M 256 449 Q 259 452 256 453 Q 253 452 256 449" fill="#ff9fb0" />
      
      {/* Tiny nose above mouth */}
      <ellipse cx="256" cy="441" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="436" x2="156" y2="431" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="210" y1="444" x2="161" y2="446" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="436" x2="356" y2="431" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      <line x1="302" y1="444" x2="351" y2="446" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.5" />
      
      {/* Tail peeking - curved */}
      <path
        d="M 362 476 Q 394 466 416 481 Q 426 491 421 501 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
