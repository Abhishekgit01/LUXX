export default function PAI_Wave_02() {
  return (
    <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Main body - cat peeking from bottom */}
      <path
        d="M 256 380 Q 200 370 170 400 Q 150 420 150 450 L 150 512 L 362 512 L 362 450 Q 362 420 342 400 Q 312 370 256 380 Z"
        fill="#1a1a1a"
      />
      
      {/* Left ear */}
      <path
        d="M 180 400 L 160 360 L 200 380 Z"
        fill="#1a1a1a"
      />
      
      {/* Right ear */}
      <path
        d="M 332 400 L 352 360 L 312 380 Z"
        fill="#1a1a1a"
      />
      
      {/* Left paw gripping edge */}
      <path
        d="M 170 440 Q 150 440 140 450 Q 130 460 135 475 Q 140 485 155 485 Q 165 485 175 475 L 180 460 Z"
        fill="#1a1a1a"
      />
      
      {/* Right paw - fully raised waving */}
      <path
        d="M 355 410 Q 375 405 385 410 Q 395 415 393 428 Q 391 438 378 442 Q 368 444 358 437 L 352 424 Z"
        fill="#1a1a1a"
      />
      
      {/* Left eye - happy squint */}
      <ellipse cx="210" cy="420" rx="22" ry="26" fill="#f8f8f8" />
      <ellipse cx="215" cy="418" rx="12" ry="15" fill="#1a1a1a" />
      <ellipse cx="217" cy="413" rx="5" ry="7" fill="#ffffff" />
      
      {/* Right eye - happy squint */}
      <ellipse cx="302" cy="420" rx="22" ry="26" fill="#f8f8f8" />
      <ellipse cx="297" cy="418" rx="12" ry="15" fill="#1a1a1a" />
      <ellipse cx="295" cy="413" rx="5" ry="7" fill="#ffffff" />
      
      {/* Tiny nose */}
      <ellipse cx="256" cy="445" rx="6" ry="5" fill="#ff9fb0" />
      
      {/* Subtle whiskers - left */}
      <line x1="210" y1="440" x2="160" y2="435" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="210" y1="448" x2="165" y2="450" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Subtle whiskers - right */}
      <line x1="302" y1="440" x2="352" y2="435" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      <line x1="302" y1="448" x2="347" y2="450" stroke="#1a1a1a" strokeWidth="1.5" opacity="0.4" />
      
      {/* Tail peeking */}
      <path
        d="M 362 480 Q 390 470 410 485 Q 420 495 415 505 L 370 512 Z"
        fill="#1a1a1a"
      />
    </svg>
  );
}
