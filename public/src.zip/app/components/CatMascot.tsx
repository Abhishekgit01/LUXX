import { motion } from 'motion/react';

interface CatMascotProps {
  mood: 'idle' | 'thinking' | 'talking';
  frame: number;
}

export function CatMascot({ mood, frame }: CatMascotProps) {
  // Animation variants for different moods
  const getAnimationProps = () => {
    switch (mood) {
      case 'idle':
        return getIdleAnimation(frame);
      case 'thinking':
        return getThinkingAnimation(frame);
      case 'talking':
        return getTalkingAnimation(frame);
      default:
        return getIdleAnimation(0);
    }
  };

  const { eyeOpen, headRotate, pawY, tailRotate, mouthOpen, earRotate } = getAnimationProps();

  return (
    <svg
      width="512"
      height="512"
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ overflow: 'visible' }}
    >
      {/* Cat body peeking from bottom-right */}
      <motion.g
        animate={{
          rotate: headRotate,
          y: mood === 'idle' ? [0, -3, 0, -2] : 0,
        }}
        transition={{
          y: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
          rotate: { duration: 0.3 }
        }}
        style={{ originX: '75%', originY: '80%' }}
      >
        {/* Head */}
        <path
          d="M 350 320 Q 420 300 460 340 Q 480 360 480 400 Q 480 450 450 480 Q 420 500 380 500 Q 340 500 320 470 Q 300 440 310 400 Q 320 360 350 320 Z"
          fill="#1a1a1a"
          stroke="#000"
          strokeWidth="2"
        />

        {/* Left Ear */}
        <motion.path
          d="M 340 330 L 320 280 L 360 310 Z"
          fill="#1a1a1a"
          stroke="#000"
          strokeWidth="2"
          animate={{ rotate: earRotate }}
          transition={{ duration: 0.3 }}
          style={{ originX: '340px', originY: '310px' }}
        />

        {/* Right Ear */}
        <motion.path
          d="M 440 320 L 470 270 L 460 330 Z"
          fill="#1a1a1a"
          stroke="#000"
          strokeWidth="2"
          animate={{ rotate: mood === 'thinking' ? -earRotate : 0 }}
          transition={{ duration: 0.3 }}
          style={{ originX: '455px', originY: '300px' }}
        />

        {/* Inner ear details */}
        <path d="M 335 315 L 330 295 L 345 315 Z" fill="#333" />
        <path d="M 450 310 L 460 290 L 455 315 Z" fill="#333" />

        {/* Whiskers - left */}
        <line x1="330" y1="390" x2="280" y2="380" stroke="#000" strokeWidth="2" strokeLinecap="round" />
        <line x1="330" y1="405" x2="280" y2="405" stroke="#000" strokeWidth="2" strokeLinecap="round" />
        <line x1="330" y1="420" x2="285" y2="430" stroke="#000" strokeWidth="2" strokeLinecap="round" />

        {/* Whiskers - right */}
        <line x1="450" y1="390" x2="500" y2="380" stroke="#000" strokeWidth="2" strokeLinecap="round" />
        <line x1="450" y1="405" x2="500" y2="405" stroke="#000" strokeWidth="2" strokeLinecap="round" />
        <line x1="450" y1="420" x2="495" y2="430" stroke="#000" strokeWidth="2" strokeLinecap="round" />

        {/* Left Eye */}
        <motion.g
          animate={{
            scaleY: eyeOpen,
          }}
          transition={{ duration: 0.15 }}
          style={{ originY: '385px' }}
        >
          <ellipse cx="360" cy="385" rx="22" ry="28" fill="#f5f5f5" />
          <ellipse cx="365" cy="390" rx="14" ry="18" fill="#000" />
          <ellipse cx="368" cy="385" rx="6" ry="8" fill="#fff" />
        </motion.g>

        {/* Right Eye */}
        <motion.g
          animate={{
            scaleY: eyeOpen,
          }}
          transition={{ duration: 0.15 }}
          style={{ originY: '385px' }}
        >
          <ellipse cx="430" cy="385" rx="22" ry="28" fill="#f5f5f5" />
          <ellipse cx="425" cy="390" rx="14" ry="18" fill="#000" />
          <ellipse cx="422" cy="385" rx="6" ry="8" fill="#fff" />
        </motion.g>

        {/* Nose */}
        <path d="M 395 420 L 390 428 L 400 428 Z" fill="#ff8fb3" />

        {/* Mouth - animated for talking */}
        <motion.g
          animate={{
            scaleY: mouthOpen,
          }}
          transition={{ duration: 0.15 }}
          style={{ originY: '435px' }}
        >
          <path
            d="M 395 428 Q 385 435 380 438 M 395 428 Q 405 435 410 438"
            stroke="#000"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
        </motion.g>
      </motion.g>

      {/* Left Paw gripping edge */}
      <motion.g
        animate={{ y: pawY }}
        transition={{ duration: 0.4 }}
      >
        <ellipse cx="320" cy="490" rx="28" ry="32" fill="#1a1a1a" stroke="#000" strokeWidth="2" />
        <ellipse cx="315" cy="485" rx="8" ry="10" fill="#333" />
        <ellipse cx="325" cy="485" rx="8" ry="10" fill="#333" />
        <ellipse cx="320" cy="498" rx="10" ry="12" fill="#333" />
      </motion.g>

      {/* Right Paw gripping edge */}
      <motion.g
        animate={{ y: mood === 'talking' ? pawY - 5 : pawY }}
        transition={{ duration: 0.4 }}
      >
        <ellipse cx="480" cy="495" rx="30" ry="34" fill="#1a1a1a" stroke="#000" strokeWidth="2" />
        <ellipse cx="475" cy="490" rx="8" ry="10" fill="#333" />
        <ellipse cx="485" cy="490" rx="8" ry="10" fill="#333" />
        <ellipse cx="480" cy="503" rx="10" ry="12" fill="#333" />
      </motion.g>

      {/* Tail peeking from bottom */}
      <motion.path
        d="M 340 500 Q 310 510 295 505 Q 280 500 275 485 Q 272 475 278 470"
        stroke="#1a1a1a"
        strokeWidth="20"
        fill="none"
        strokeLinecap="round"
        animate={{ rotate: tailRotate }}
        transition={{ duration: 0.5 }}
        style={{ originX: '320px', originY: '490px' }}
      />

      {/* Thinking indicators - only show in thinking mode */}
      {mood === 'thinking' && (
        <motion.g
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <circle cx="320" cy="280" r="8" fill="#4dd4e8" opacity="0.8" />
          <circle cx="340" cy="250" r="12" fill="#4dd4e8" opacity="0.6" />
          <circle cx="370" cy="230" r="16" fill="#4dd4e8" opacity="0.4" />
        </motion.g>
      )}
    </svg>
  );
}

// Animation frame calculations
function getIdleAnimation(frame: number) {
  const cycle = frame % 4;
  return {
    eyeOpen: cycle === 2 ? 0.1 : 1, // Blink on frame 2
    headRotate: 0,
    pawY: cycle === 1 ? -3 : cycle === 3 ? -2 : 0,
    tailRotate: [2, 4, 2, 0][cycle],
    mouthOpen: 1,
    earRotate: 0,
  };
}

function getThinkingAnimation(frame: number) {
  const cycle = frame % 4;
  return {
    eyeOpen: 1,
    headRotate: [-3, -5, -4, -2][cycle],
    pawY: cycle === 2 ? -8 : -5,
    tailRotate: [3, 5, 4, 3][cycle],
    mouthOpen: 1,
    earRotate: [2, 4, 3, 2][cycle],
  };
}

function getTalkingAnimation(frame: number) {
  const cycle = frame % 4;
  return {
    eyeOpen: 1,
    headRotate: [0, 1, 0, -1][cycle],
    pawY: [0, -4, -2, -4][cycle],
    tailRotate: [5, 8, 6, 7][cycle],
    mouthOpen: [1, 1.5, 1.2, 1.6][cycle],
    earRotate: 0,
  };
}
